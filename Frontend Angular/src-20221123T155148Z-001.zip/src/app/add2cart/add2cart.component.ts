import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add2cart',
  templateUrl: './add2cart.component.html',
  styleUrls: ['./add2cart.component.css']
})
export class Add2cartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
